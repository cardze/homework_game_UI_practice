package game;

public class RoleDetailController {
}
