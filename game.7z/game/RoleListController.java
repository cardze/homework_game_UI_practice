package game;

import javafx.scene.input.MouseEvent;

public class RoleListController {
    public void OnClickShowDetail_0(MouseEvent mouseEvent) {
    }

    public void OnClickShowDetail_1(MouseEvent mouseEvent) {
    }

    public void OnClickShowDetail_2(MouseEvent mouseEvent) {
    }

    public void OnClickShowDetail_3(MouseEvent mouseEvent) {
    }

    public void OnClickShowDetail_4(MouseEvent mouseEvent) {
    }

    public void OnMouseClicked(MouseEvent mouseEvent) {
    }
}
