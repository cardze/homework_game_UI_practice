package game.model;

enum TaskState {
    WORK,
    EXAM,
    EVENT,
    SPECIALWORK,
    NONE
}
