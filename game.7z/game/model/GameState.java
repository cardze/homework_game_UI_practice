package game.model;

public enum GameState {
    WIN,
    LOSE,
    CONTINUE
}
