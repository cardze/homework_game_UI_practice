package game.testing_file;

enum TaskState {
    work ,
    exam ,
    event ,
    specialwork ,
    none
}
