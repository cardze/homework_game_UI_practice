package game.testing_file;

public class ComputerCamp extends Event{

    public ComputerCamp(){
        this.eventName = "電腦營";
        this.doneValue = 100;
        this.remainDays = 20;
        YS ys = new YS();
        list.add(ys);
    }

}
