package game.testing_file;

enum GameState {
    win,
    lose,
    conti
}
